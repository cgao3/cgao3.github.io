#include "scp.h"
//int uncover[MAXR];
//int index_uncover[MAXR];
int *uncover;
int *index_uncover;
int uncover_num; 
int c_size=0;
double cutofftime;

void init(){
	int i,j,l;
	n_bestSol=0;
	best_value=INT_MAX;
	uncover_num=m;
	uncover=(int*)malloc(m*sizeof(int));
	index_uncover=(int*)malloc(m*sizeof(int));

	for(i=0;i<m;i++){
		if(ncol[i]>0){
			uncover[i]=i;
			index_uncover[i]=i;
		} else printf("error\n");
		if(ncol[i]==1) {
			col_fix[row[i][0]]=1;
		}
	}
	c_size=0;
	nsol=0;
	tabu[0]=tabu[1]=-1;
	printf("init end\n");
}

void init_best(){
	int cnt;
	int i,j,k,l,jj;
	int maxScore=-100 ;
	while(uncover_num>0){
		cnt=0;
		maxScore=INT_MIN;
		for(j=0;j<n;j++){
			if(cs[j].is_in_c) continue;
			if(col_fix[j]) { add(j); continue; }
			if(maxScore<cs[j].score){
				maxScore=cs[j].score;
				best_array[0]=j;
				cnt=1;
			} else if(maxScore==cs[j].score){
				best_array[cnt++]=j;
			}
		}
		if(cnt>0){
			l=rand()%cnt;
			add(best_array[l]);
		}
	}
	
	update_best_sol();
	printf("initial solution:%d\n",best_value);
}
void add(int c){
	int i,j,k,t,cnt,s, ii, jj, ix,h, l;
	cs[c].is_in_c=1;
	cs[c].score=-cs[c].score;
	c_size++;
	for(h=0;h<nrow[c]; h++){
		i=col[c][h];
		if(index_uncover[i]!=-1){
			ii=index_uncover[i];
			for(jj=ii;jj<uncover_num-1;jj++){
				uncover[jj]=uncover[jj+1];
				index_uncover[uncover[jj]]=jj;
			}
			uncover_num--;
			index_uncover[i]=-1;
			
			for(l=0; l<ncol[i]; l++){ // c is the first one covering i 
				j=row[i][l];
				if(j==c) continue;
				cs[j].config=1;
				cs[j].score-=rs[i].weight;
			}
		} else {
			cnt=0;
			for(l=0;l<ncol[i];l++){
				j=row[i][l];
				if(j==c) continue;
				if(cs[j].is_in_c){
					s=j;
					cnt++;
				}
			    cs[j].config=1;
			}
			if(cnt==1){ // c is the second one covering this row in C 
				cs[s].score+=rs[i].weight;
			}
		}
	}
	sol[nsol]=c;
	nsol++;
}
void remove_one(int c){
	cs[c].is_in_c=0;
	cs[c].score=-cs[c].score;
	cs[c].config=0;
	int i,j,k,t,cnt,s,h,l;
	for(h=0; h<nrow[c]; h++){
		i=col[c][h];
		cnt=0;
		for(l=0;l<ncol[i];l++){
			j=row[i][l];
			if(j==c) continue;
			if(cs[j].is_in_c){
				cnt++;
				s=j;
			}
			cs[j].config=1;
		}
		if(cnt==0){
			uncover[uncover_num]=i;
			index_uncover[i]=uncover_num;
			uncover_num++;
			for(l=0;l<ncol[i];l++){
				j=row[i][l];
				if(j==c) continue;
				cs[j].score+=rs[i].weight;
			}
		} else if(cnt==1){
			cs[s].score-=rs[i].weight;
		}
	}
	for(l=0;l<nsol;l++){
		if(sol[l]==c){
			break;
		}
	}
	for(;l<nsol-1;l++) sol[l]=sol[l+1];
	nsol--;
	c_size--;
}
int find_best_in_c(int allowTabu){
	int i, maxc=-1,j,l;
	int maxScore=INT_MIN ;
	for(l=0;l<nsol;l++){
		j=sol[l];
		if(!cs[j].is_in_c) continue;
		if(allowTabu&&(j==tabu[0]||j==tabu[1])) continue;
		if(col_fix[j] == 1) continue;
		if(maxScore<cs[j].score){
			maxScore=cs[j].score;
			maxc=j;
		} else if(maxScore==cs[j].score){
			if(cs[maxc].time_stamp>cs[j].time_stamp){
				maxc=j;
			}	
		}
	}
	return maxc;
}

void adjust_weights(){
	int i,j,k,total=0,cnt,s,ix,h,l;	

	for(i=0;i<uncover_num;i++){
		rs[uncover[i]].weight+=1;
		for(h=0;h<ncol[uncover[i]];h++){
			j=row[uncover[i]][h];
			cs[j].score+=1;
		}
	}
}
void simulation(){
    init();
    int i,j,k,l;
    while(uncover_num>0){
       k=rand()%uncover_num;
       i=uncover[k];
       j=rand()%ncol[i];
       add(j);
    }
}

void localsearch(int maxStep){
	step=1;
	int i,j,k,h,l,cnt=0;
	int best_in_c;
	int maxc;
	while(1){
		if(uncover_num==0){
			update_best_sol();
			if(best_value<=BEST){
				printf("optimum found\n");
				break;
			}
			maxc=find_best_in_c(0);
			remove_one(maxc);
			continue;
		}
		best_in_c=find_best_in_c(1);
		remove_one(best_in_c);
		cs[best_in_c].time_stamp=step;
		//	k=my_rand_from(0,uncover_num-1);
		k=rand()%uncover_num;
		i=uncover[k];
	    int maxScore=INT_MIN, maxc=0;
		for(h=0; h<ncol[i];h++){
			j=row[i][h];
			if(!cs[j].config) continue;
			if(maxScore<cs[j].score){
				maxScore=cs[j].score; 
				maxc=j;
			} else if(maxScore==cs[j].score&&cs[maxc].time_stamp>cs[j].time_stamp){
				maxc=j;
			}
		}
		add(maxc);
		tabu[0]=tabu[1];
		tabu[1]=maxc;
		cs[maxc].time_stamp=step;
		adjust_weights();
		step++;
		if(step>=maxStep ||cpu_time()-start_time>cutofftime){
			break; 
		}
	}
}

void update_best_sol(){
	int i,j;
	if(c_size<best_value){
		printf("sol %d, time %.2f, step %d\n", c_size, cpu_time()-start_time,step);
		n_bestSol=0;
		best_value=c_size;
		for(j=0;j<n;j++){
			if(cs[j].is_in_c){
				best_sol[n_bestSol++]=j;
			}
		}
	}
}
int check(){ // check if the solution is a correct cover
	int i,j,k;
	int *t=malloc((m+1)*sizeof(int));
	memset(t,0,(m+1)*sizeof(int));
	for(i=0;i<n_bestSol;i++){
		j=best_sol[i];
		for(k=0;k<nrow[j];k++){
			t[col[j][k]]=1;
		}
	}
	for(i=0;i<m;i++){
		if(ncol[i]&&!t[i]) return 0;
	}
	free(t);
	return 1;
}
void print_sol(){
	int i;
	for(i=0;i<n_bestSol;i++){
		printf("%d\t",best_sol[i]+1);
	}
	printf("\n");
}
int main(int argc, char *argv[]){
	struct tms start, end;
	if(argc<5){
		printf("usage ./msp file BEST seed maxStep time_limit\n");
		return 0;
	}
	int total_step;
	build_instance2(argv[1]);
	BEST=atoi(argv[2]);
	seed=atoi(argv[3]);
	total_step=atoi(argv[4]);
	cutofftime=atof(argv[5]);
	srand(seed);
	init();
	times(&start);
	init_best();
	localsearch(total_step);
	times(&end);
	printf("final best:%d\n", best_value);
	printf("search steps is %d, seed is %d\n",step,seed);
	if(!check()) printf("wrong answer \n");
	printf("time cost %f s\n", (end.tms_utime-start.tms_utime)*1.0/sysconf(_SC_CLK_TCK));
//	print_sol();
	//free_all();
	//free(uncover);
	//free(index_uncover);
	return 0;
}

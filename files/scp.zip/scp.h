#include<stdio.h>
#include<stdlib.h>
#include<limits.h>
#include<float.h>
#include<memory.h>
#include<sys/times.h>
#include<unistd.h>
#include<math.h> 
#include "cpu_time.c"

#define MAXC 950000
#define MAXR 5000

#define MAX(a,b) (a>b)?a:b
#define MIN(a,b) (a<b)?a:b

typedef struct Column_st{
	int score;
	int time_stamp;
	char config;
	char is_in_c;
}Column;

typedef struct Row_st{
	int weight;
}Row;

Column *cs;
Row *rs;

int nselect;
//int best_sol[MAXR];
int *best_sol;
int n_bestSol;

//int tabu[MAXR];
int tabu[2];

int m,n;
int seed;
int BEST;
int step;
//int best_array[MAXC];
int *best_array;
int best_value;
int no_improve=0;

int **row, **col;
int *ncol, *nrow;
int *col_fix;
int *sol;
int nsol;
int nonzero_elements;
double start_time;


void init();
void init_best();
void localsearch(int);
void add(int);
void remove_one(int);
int find_best_in_c(int);
void adjust_weights();
void update_best_sol();

void free_all();

void free_all(){
	free(row);
	free(col);
	free(ncol);
	free(nrow);
}
/*OR-Lib instances */
void build_instance2(char *file){
	int i,j,h,t;
	int *k_t;
	freopen(file,"r",stdin);
	scanf("%d%d",&m,&n);
	cs=(Column*)malloc(n*sizeof(Column));
	rs=(Row *)malloc(m*sizeof(Row));
	nonzero_elements=0;
	row=(int **)malloc(m*sizeof(int*));
	ncol=(int *)malloc(m*sizeof(int));
	
	col_fix=(int *)malloc(n*sizeof(int));
	col=(int **)malloc(n*sizeof(int *));
	nrow=(int *)malloc(n*sizeof(int));
	k_t=(int *)malloc(n*sizeof(int));
	t=m<n?m:n;
	sol=(int*)malloc(t*sizeof(int));
	best_array=(int*)malloc(t*sizeof(int));
	best_sol=(int*)malloc(t*sizeof(int));
	nsol=0;
	//ignore the cost
	for(j=0;j<n;j++){
		scanf("%d",&i);
		cs[j].config=1;
		cs[j].time_stamp=0;
		cs[j].is_in_c=0;
		nrow[j]=0;
		col_fix[j]=0;
	}
	for(i=0;i<m;i++) {
		scanf("%d",&ncol[i]);   
		nonzero_elements += ncol[i];
		row[i]=(int *)malloc(ncol[i]*sizeof(int));
		for(h=0;h<ncol[i];h++) {
			scanf("%d",&row[i][h]);
			row[i][h]--;
		}
		rs[i].weight=1;
	}
	for(i=0;i<m;i++) {
		for(h=0;h<ncol[i];h++) nrow[row[i][h]]++;
	}
	for(j=0;j<n;j++) {
		if(nrow[j]<=0) printf("--error %d\n",nrow[j]);
		col[j]=(int *)malloc((nrow[j])*sizeof(int)); 
		k_t[j]=0;
		cs[j].score=nrow[j];
	}
	for(i=0;i<m;i++) {
		for(h=0;h<ncol[i];h++) {
			col[row[i][h]][k_t[row[i][h]]]=i; 
			k_t[row[i][h]]++;
		}
	}
	free(k_t);
	int min_cover=INT_MAX, max_cover=0;
	int avg_cover, sum=0;
	for(i=0;i<m;i++){
		if(min_cover>ncol[i]) min_cover=ncol[i];
		if(max_cover<ncol[i]) max_cover=ncol[i];
		sum+=ncol[i];
	}
	avg_cover=sum/m;
	printf("density:%.6f\n", sum*1.0/m/n*1.0);
	printf("max cover num:%d, min %d, average %d\n",max_cover,min_cover,avg_cover);
	printf("build instance time cost %.2f\n", cpu_time());
	start_time=cpu_time();
}
